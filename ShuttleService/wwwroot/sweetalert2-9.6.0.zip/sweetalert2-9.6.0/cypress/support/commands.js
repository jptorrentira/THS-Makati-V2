// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add("login", (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add("drag", { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add("dismiss", { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite("visit", (originalFn, url, options) => { ... })

const fetchStyles = (target, linkHref) => {
  return new Promise((resolve) => {
    const link = document.createElement('link')
    link.setAttribute('rel', 'stylesheet')
    link.onload = resolve
    link.setAttribute('href', linkHref)
    target.appendChild(link)
  })
}

before(async () => {
  await fetchStyles(parent.document.head, '/cypress/styles.css')
  await fetchStyles(document.head, '/dist/sweetalert2.css')
})
